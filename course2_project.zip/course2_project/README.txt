Insert the function to core.py in modern_robotics packages (in installation directory).

Use course2_prj.py to test the function on UR5